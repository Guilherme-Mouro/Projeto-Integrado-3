import 'package:flutter/material.dart';
import 'package:first_app/gradiant_container.dart';

void main() {
  runApp(
     const MaterialApp(
      home: Scaffold(
        body: GradiantContainer(
          colors: [
            Color.fromARGB(255, 130, 68, 205), 
            Color.fromARGB(255, 226, 19, 161)
        ]),
      ),
    ),
  );
}
