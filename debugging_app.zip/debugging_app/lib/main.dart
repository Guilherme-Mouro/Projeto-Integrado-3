import 'package:flutter/material.dart';

import 'package:adv_basics/quiz.dart';

void main() {
  runApp(const Quiz());
}
