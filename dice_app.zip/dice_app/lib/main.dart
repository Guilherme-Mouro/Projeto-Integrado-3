import 'package:flutter/material.dart';
import 'package:dice_app/gradiant_container.dart';

void main() {
  runApp(
     const MaterialApp(
      home: Scaffold(
        body: GradiantContainer(
          colors: [
            Color.fromARGB(255, 11, 7, 94), 
            Color.fromARGB(255, 207, 145, 20)
        ]),
      ),
    ),
  );
}
